import boto3
def lambda_handler(event, context):
   s3 = boto3.resource('s3')
   source_bucket= 'ut-input-data'
   destination_bucket = 'ut-output-data'
   bucket = s3.Bucket(source_bucket)
   try:
      for file in bucket.objects.all():
         copy_source = {'Bucket': source_bucket,'Key': file.key}
         s3.meta.client.copy(copy_source,Bucket = destination_bucket, Key=file.key)
         return 'SUCCESS'
   except Exception as err:
      print ("Error -"+str(err))
      return e